# Diabolik Euromillions

Projet de génération et vérification de grilles Euromillions.